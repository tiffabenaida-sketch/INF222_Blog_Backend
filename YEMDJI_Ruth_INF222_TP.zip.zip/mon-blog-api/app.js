const express = require('express');
const swaggerUi = require('swagger-ui-express');
const app = express();

app.use(express.json());

// Configuration de la documentation Swagger
const swaggerDocument = {
  openapi: '3.0.0',
  info: {
    title: 'API Blog — INF222 TAF1',
    version: '1.0.0',
    description: 'API REST pour gérer un blog simple.\nDéveloppée dans le cadre du cours INF222 EC1 (Développement Backend).\n\n## Fonctionnalités\n- CRUD complet sur les articles\n- Filtrage par catégorie, auteur, date\n- Recherche full-text',
  },
  servers: [
    {
      url: 'http://localhost:4000',
      description: 'Serveur de développement local'
    }
  ],
  paths: {
    '/api/articles/search': {
      get: {
        tags: ['Articles'],
        summary: 'Rechercher des articles',
        responses: { 200: { description: 'Succès' } }
      }
    },
    '/api/articles': {
      get: {
        tags: ['Articles'],
        summary: 'Récupérer tous les articles',
        responses: { 200: { description: 'Succès' } }
      },
      post: {
        tags: ['Articles'],
        summary: 'Créer un nouvel article',
        responses: { 201: { description: 'Article créé' } }
      }
    },
    '/api/articles/{id}': {
      get: {
        tags: ['Articles'],
        summary: 'Récupérer un article par son ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'Succès' } }
      },
      put: {
        tags: ['Articles'],
        summary: 'Modifier un article',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'Mis à jour' } }
      },
      delete: {
        tags: ['Articles'],
        summary: 'Supprimer un article',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 204: { description: 'Supprimé' } }
      }
    }
  }
};

// Route pour la doc
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Lancement du serveur
const PORT = 4000;
app.listen(PORT, () => {
    console.log(`SUCCES : http://localhost:${PORT}/api-docs`);
});

// Empêche le processus de s'arrêter brutalement en cas d'erreur
process.on('uncaughtException', (err) => {
    console.log('Erreur capturée :', err.message);
});
